package os;

public class Timer extends Thread{

	public Timer(Interrupt interrupt){
		
	}
	
	public void run() {
		
	}
}
