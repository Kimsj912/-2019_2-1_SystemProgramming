package ioDevice;

public class IODevice {
	public IODevice() {
		
	}

}
