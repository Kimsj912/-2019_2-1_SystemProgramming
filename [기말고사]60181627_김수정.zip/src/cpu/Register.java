package cpu;

public class Register {
	int data;
	public int getData() {return data;}
	public void setData(int data) {	this.data = data;}
	
	public Register() {
		
	}
	String name;
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	

}
